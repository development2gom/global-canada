/*!
 * remark v1.0.6 (http://getbootstrapadmin.com/remark)
 * Copyright 2015 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */
(function(document, window) {
  'use strict';

  window.AppForum = App.extend({
    run: function(next) {
      next();
    }
  });
})(document, window);
