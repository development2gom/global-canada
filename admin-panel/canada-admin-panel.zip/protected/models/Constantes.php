<?php
class Constantes {
	public $coordenadas = array (
			array ( // 1
					"x" => 0,
					"y" => 0,
					"w" => 2,
					"h" => 2 
			),
			array ( // 2
					"x" => 2,
					"y" => 0,
					"w" => 2,
					"h" => 4 
			),
			array ( // 3
					"x" => 0,
					"y" => 2,
					"w" => 2,
					"h" => 2 
			),
			array ( // 4
					"x" => 4,
					"y" => 0,
					"w" => 4,
					"h" => 2 
			),
			array ( // 5
					"x" => 4,
					"y" => 2,
					"w" => 2,
					"h" => 2 
			),
			array ( // 6
					"x" => 6,
					"y" => 2,
					"w" => 2,
					"h" => 2 
			),
			array ( // 7
					"x" => 8,
					"y" => 0,
					"w" => 2,
					"h" => 2 
			),
			array ( // 8
					"x" => 10,
					"y" => 0,
					"w" => 2,
					"h" => 4 
			),
			array ( // 9
					"x" => 8,
					"y" => 2,
					"w" => 2,
					"h" => 2 
			),
			array ( // 10
					"x" => 0,
					"y" => 4,
					"w" => 4,
					"h" => 2 
			),
			array ( // 11
					"x" => 0,
					"y" => 6,
					"w" => 2,
					"h" => 2 
			),
			array ( // 12
					"x" => 2,
					"y" => 6,
					"w" => 2,
					"h" => 2 
			),
			array ( // 13
					"x" => 4,
					"y" => 4,
					"w" => 2,
					"h" => 2 
			),
			array ( // 14
					"x" => 6,
					"y" => 4,
					"w" => 2,
					"h" => 4 
			),
			array ( // 15
					"x" => 4,
					"y" => 6,
					"w" => 2,
					"h" => 2 
			),
			array ( // 16
					"x" => 8,
					"y" => 4,
					"w" => 2,
					"h" => 2 
			),
			array ( // 17
					"x" => 10,
					"y" => 4,
					"w" => 2,
					"h" => 2 
			),
			array ( // 18
					"x" => 8,
					"y" => 6,
					"w" => 4,
					"h" => 2 
			) 
	);
	public $colors = array (
			"dgom-ui-judge-progress-box-header-blue",
			"dgom-ui-judge-progress-box-header-green",
			"dgom-ui-judge-progress-box-header-orange",
			"dgom-ui-judge-progress-box-header-red",
			//"dgom-ui-judge-progress-box-header-blue" 
	);
}