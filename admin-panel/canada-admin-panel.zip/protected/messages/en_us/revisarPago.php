<?php
return array(
		'procesandoPago'=>'Processing your payment, pls hold on',
		'loading'=>'images ',
);