<?php
return array(
		'header'=>'POR FAVOR SELECCIONA TU TIPO DE INSCRIPCIÓN',
		'note'=>'*El costo es una cuota de recuperación',
		'terminos'=>'Acepto términos y condiciones',
		'headerTerminos'=>'Términos y condiciones',
		'acepto'=>'Acepto términos y condiciones',
		'warningProducto'=>'Por favor debe seleccionar un tipo de inscripción',
		'submit'=>'Continuar'
);