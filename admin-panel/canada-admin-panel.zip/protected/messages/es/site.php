<?php

return array(

	'progreso'=>'Overall Progress',

	'progresoJueces'=>'Judge Progress',

	'competitors'=>'Competitors',

	'finalists'=>'Finalists',

	'finalistsTop'=>'FinalistsTop',

	'menciones'=>'Menciones',

	'categoryConflicts'=>'Category conflicts',

	'sessionStar'=>'Admin panel',

	'siteDesarrollado'=>'Powered by',

	'siteDesarrolladoAuthor'=>'2 Geeks one Monkey',

	'selectOrdenBy'=>'Sort by',

	'progresoProgress'=>'Progress',

	'filters'=>'Filters',

	'score'=>'Score',

	'viewPhoto'=>'View Photo',

	'honorableMentions'=>'With Honorable Mentions',

	'titleLogin'=>'Global Judging - Login',

	'titleJudgePanel'=>'Global Judging - Judge Panel',

	'titlePhotosCategory'=>'Global Judging - Photo Collage',

	'titlePhotoReview'=>'Global Judging - Photo Review',

	'titleAdminPanel'=>'Global Judging - Admin Panel',

	'titleJudgeProgress'=>'Global Judging - Judge Progress',

	'titleCompetitors'=>'Global Judging - Competitors',

	'progress'=>'Progress',	

);