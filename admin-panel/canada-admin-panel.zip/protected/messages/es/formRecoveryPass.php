<?php
return array(
	'instrucciones'=>'Para recuperar tu contraseña necesitamos nos proporciones el correo electrónico con el que te registraste',
	'submit'=>'Recuperar contraseña',
		
);