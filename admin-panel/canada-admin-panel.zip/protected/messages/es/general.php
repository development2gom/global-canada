<?php
return array(
		'textFooter'=>'Powered by 2 Geeks one Monkey S.C.',
		'bienvenido'=>'Bienvenido al concurso',
		'consulta'=>'Consulta las bases del concurso',
		'derechos'=>'All Right Reserved',
		'saludo'=>'Hola'
);