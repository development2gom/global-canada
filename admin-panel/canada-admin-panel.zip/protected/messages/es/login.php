<?php
return array(
	'title'=>'Concurso de Fotografía Mexicano Haz clic con México - Bienvenido',
	'loginFormHeader'=>'Comite Fotográfico Mexicano',
	'instrucciones'=>'Por favor ingresa los datos de tu cuenta',
	'usuario'=>'Correo electrónico',
	'password'=>'Contraseña',
	'olvidePass'=>'Olvide mi contraseña',
	'necesitarCuenta'=>'Necesito una cuenta',
	'facebook'=>'Ingresar con Facebook',
	'errorInicio'=>'Usuario y/o password incorrecto.',
	'ingresar'=>'Ingresar',
	'user'=>'Usuario'
);