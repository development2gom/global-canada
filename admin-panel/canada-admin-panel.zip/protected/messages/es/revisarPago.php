<?php
return array(
		'procesandoPago'=>'Procesando pago',
		'loading'=>'Cargando',
);