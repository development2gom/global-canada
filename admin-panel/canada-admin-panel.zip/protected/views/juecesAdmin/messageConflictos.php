<?php
echo Yii::t('finalists', 'conflicts');