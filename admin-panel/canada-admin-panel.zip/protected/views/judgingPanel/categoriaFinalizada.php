<div class="container">
	<div class="row padding-50">
		<div class="pleca-finished">
			<div class="finished-header">
				<h2>You just finished Thank You!</h2>
			</div>
			<div class="finished-contend">
				<p>
					If the situation of a tie-breaker should arise, you will be notified via email, with the respective instructions of how to  resolve such tie-breaker. 
				</p>
			</div>
		</div>
	</div>
</div>